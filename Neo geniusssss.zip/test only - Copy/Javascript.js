// ---------------- VARIABLES ---------------- //
let currentQuestionIndex = 0;
let score = 0;
let timeLeft = 60;
let timer;
let quizData = [];

// Elements
const quizContainer = document.getElementById("quiz");
const questionText = document.getElementById("question-text");
const optionsContainer = document.getElementById("options-container");
const nextButton = document.getElementById("next-btn");
const timerDisplay = document.getElementById("time-left");
const progressBar = document.getElementById("progress-bar");
const leaderboardBody = document.getElementById("leaderboard-body");

// ---------------- DARK MODE TOGGLE ---------------- //
const darkModeToggle = document.getElementById("dark-mode-toggle");
darkModeToggle.addEventListener("click", function () {
    document.body.classList.toggle("dark-mode");
    darkModeToggle.textContent = document.body.classList.contains("dark-mode") ? "☀️" : "🌙";
});

// ---------------- QUIZ QUESTIONS ---------------- //
const allQuestions = [
    { question: "What is the capital of France?", options: ["Berlin", "Madrid", "Paris", "Lisbon"], correct: "Paris" },
    { question: "Which programming language is known as the backbone of web development?", options: ["Java", "Python", "JavaScript", "C++"], correct: "JavaScript" },
    { question: "Who developed the theory of relativity?", options: ["Isaac Newton", "Albert Einstein", "Nikola Tesla", "Galileo Galilei"], correct: "Albert Einstein" },
    { question: "What is the largest planet in our Solar System?", options: ["Earth", "Jupiter", "Mars", "Saturn"], correct: "Jupiter" },
    { question: "What is the capital of Japan?", options: ["Tokyo", "Kyoto", "Osaka", "Seoul"], correct: "Tokyo" },
    { question: "Who painted the Mona Lisa?", options: ["Vincent van Gogh", "Leonardo da Vinci", "Pablo Picasso", "Michelangelo"], correct: "Leonardo da Vinci" },
    { question: "Which planet is known as the Red Planet?", options: ["Mars", "Jupiter", "Mercury", "Saturn"], correct: "Mars" },
    { question: "What is the smallest bone in the human body?", options: ["Femur", "Patella", "Stapes", "Tibia"], correct: "Stapes" },
    { question: "Who wrote 'Romeo and Juliet'?", options: ["William Shakespeare", "George Bernard Shaw", "Arthur Miller", "Anton Chekhov"], correct: "William Shakespeare" },
    { question: "Which ocean is the largest?", options: ["Pacific Ocean", "Atlantic Ocean", "Indian Ocean", "Arctic Ocean"], correct: "Pacific Ocean" },
    { question: "What is the chemical symbol for water?", options: ["H2O", "CO2", "O2", "CH4"], correct: "H2O" },
    { question: "Who is known as the 'Father of Computers'?", options: ["Alan Turing", "Charles Babbage", "Ada Lovelace", "Bill Gates"], correct: "Charles Babbage" },
    { question: "Which country is famous for its tulips?", options: ["Netherlands", "Belgium", "France", "Italy"], correct: "Netherlands" },
    { question: "Who discovered penicillin?", options: ["Alexander Fleming", "Louis Pasteur", "Marie Curie", "Gregor Mendel"], correct: "Alexander Fleming" }
];

// Shuffle function to randomize questions
function shuffle(array) {
    for (let i = array.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [array[i], array[j]] = [array[j], array[i]];
    }
    return array;
}

// Select 10 random questions without repetition
quizData = shuffle([...allQuestions]).slice(0, 10);

// ---------------- START QUIZ ---------------- //
function startQuiz() {
    document.getElementById("home").classList.add("hidden");
    quizContainer.classList.remove("hidden");
    currentQuestionIndex = 0;
    score = 0;
    timeLeft = 60;
    updateProgressBar();
    startTimer();
    loadQuestion();
}

// ---------------- LOAD QUESTION ---------------- //
function loadQuestion() {
    resetOptions();
    if (currentQuestionIndex >= quizData.length) {
        endQuiz();
        return;
    }
    let currentQuestion = quizData[currentQuestionIndex];
    questionText.textContent = currentQuestion.question;

    currentQuestion.options.forEach(option => {
        let button = document.createElement("button");
        button.classList.add("option");
        button.textContent = option;
        button.addEventListener("click", () => checkAnswer(option, currentQuestion.correct));
        optionsContainer.appendChild(button);
    });
}

// ---------------- CHECK ANSWER ---------------- //
function checkAnswer(selected, correct) {
    let buttons = document.querySelectorAll(".option");
    buttons.forEach(button => {
        if (button.textContent === correct) {
            button.style.background = "green";
        } else if (button.textContent === selected) {
            button.style.background = "red";
        }
        button.disabled = true;
    });

    if (selected === correct) {
        score += 10;
    }

    setTimeout(() => {
        nextQuestion();
    }, 1000);
}

// ---------------- NEXT QUESTION ---------------- //
function nextQuestion() {
    currentQuestionIndex++;
    updateProgressBar();
    loadQuestion();
}

// ---------------- RESET OPTIONS ---------------- //
function resetOptions() {
    optionsContainer.innerHTML = "";
}

// ---------------- START TIMER ---------------- //
function startTimer() {
    timer = setInterval(() => {
        timeLeft--;
        timerDisplay.textContent = timeLeft;
        if (timeLeft <= 0) {
            clearInterval(timer);
            endQuiz();
        }
    }, 1000);
}

// ---------------- UPDATE PROGRESS BAR ---------------- //
function updateProgressBar() {
    let progress = ((currentQuestionIndex + 1) / quizData.length) * 100;
    progressBar.innerHTML = `<div style="width: ${progress}%;"></div>`;
}

// ---------------- END QUIZ ---------------- //
function endQuiz() {
    clearInterval(timer);
    quizContainer.innerHTML = `<h2>Quiz Completed!</h2><p>Your Score: <strong>${score}</strong></p><button onclick="restartQuiz()">Restart</button>`;
    updateLeaderboard();
}

// ---------------- RESTART QUIZ ---------------- //
function restartQuiz() {
    document.location.reload();
}

// ---------------- UPDATE LEADERBOARD ---------------- //
function updateLeaderboard() {
    let playerName = prompt("Enter your name for the leaderboard:") || "Anonymous";
    let leaderboard = JSON.parse(localStorage.getItem("leaderboard")) || [];
    leaderboard.push({ name: playerName, score: score });
    leaderboard.sort((a, b) => b.score - a.score);
    localStorage.setItem("leaderboard", JSON.stringify(leaderboard));
    displayLeaderboard();
}